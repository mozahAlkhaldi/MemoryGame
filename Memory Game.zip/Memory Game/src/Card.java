import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Card {

	private JButton button;
	private ImageIcon icon;
	public Card(String file)
	{
		 icon = new ImageIcon(file);
         button = new JButton("");
         button.setBackground(Color.decode("#1C282F"));
	}
	public Card(ImageIcon icon2) 
	{
		 icon = icon2;
         button = new JButton("");
         button.setBackground(Color.decode("#1C282F"));
	}
	
	public JButton getButton()
	{
		return button;
	}
	public ImageIcon getIcon()
	{
		return icon;
	}
	public void setIcon(ImageIcon icon2) {
		icon = icon2;
	}
}
