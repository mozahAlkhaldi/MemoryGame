import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.Random;


public class Game extends JFrame {

    static String Symbols[] = {"1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png"};
    static Card[] cards;
    ImageIcon wrapper;
    int symbolsCount;
    Timer cardTimerr;
    int clickCount = 0;
    int previousTile = 0;
    int currentTile = 0;

    public Game() {
    	setPreferredSize(new Dimension(250, 250));
    	getContentPane().setBackground(Color.decode("#46A2CC"));
        setTitle("Memory Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4,4,5, 10));

        wrapper = new ImageIcon("wrapper.png");
        symbolsCount = Symbols.length * 2;
        cards = new Card[symbolsCount];

        for (int i = 0, j = 0; i < Symbols.length; i++) 
        {
            cards[j] = new Card(Symbols[i]);
            cards[j].getButton().addActionListener(new ImageButtonListener());
            cards[j].getButton().setIcon(wrapper);
            add(cards[j++].getButton());

            cards[j] = new Card(cards[j-1].getIcon());
            cards[j].getButton().addActionListener(new ImageButtonListener());
            cards[j].getButton().setIcon(wrapper);
            add(cards[j++].getButton());
        }

        // shuffle cards
        Random gen = new Random();
        for (int i = 0; i < symbolsCount; i++) {
            int rand = gen.nextInt(symbolsCount);
            ImageIcon temp = cards[i].getIcon();
            cards[i].setIcon(cards[rand].getIcon());
            cards[rand].setIcon(temp);
        }

        pack();
        setVisible(true);

        cardTimerr = new Timer(1000, new TimerListener());
    }

    private class TimerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            cards[currentTile].getButton().setIcon(wrapper);
            cards[previousTile].getButton().setIcon(wrapper);
            cardTimerr.stop();
        }
    }

    private class ImageButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            
            if (cardTimerr.isRunning())
                return;
            
            clickCount++;
            
            for (int i = 0; i < symbolsCount; i++) {
                if (e.getSource() == cards[i].getButton()) {
                    cards[i].getButton().setIcon(cards[i].getIcon());
                    currentTile = i;
                }
            }
            
            if (clickCount % 2 == 0) {
                if (currentTile == previousTile) {
                    clickCount--;
                    return;
                }
                //if cards are not matched 
                if (cards[currentTile].getIcon() != cards[previousTile].getIcon()) {
                    cardTimerr.start(); // display card for a while and disappear
                }
            } else {
                previousTile = currentTile;
            }
        }
    }
}